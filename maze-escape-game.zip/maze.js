
const canvas = document.getElementById("mazeCanvas");
const ctx = canvas.getContext("2d");
const rows = 15, cols = 15;
const size = canvas.width / cols;

let maze = [];
let visited = [];
let stack = [];
let player = { x: 0, y: 0 };
let enemy = { x: cols - 1, y: rows - 1 };
let timer = 60;
let powerup = null;
let gameOver = false;

function generateMaze() {
  for (let y = 0; y < rows; y++) {
    maze[y] = [];
    visited[y] = [];
    for (let x = 0; x < cols; x++) {
      maze[y][x] = { top: true, right: true, bottom: true, left: true };
      visited[y][x] = false;
    }
  }
  let current = { x: 0, y: 0 };
  visited[0][0] = true;
  stack.push(current);

  while (stack.length > 0) {
    let neighbors = getUnvisitedNeighbors(current);
    if (neighbors.length > 0) {
      let next = neighbors[Math.floor(Math.random() * neighbors.length)];
      removeWalls(current, next);
      visited[next.y][next.x] = true;
      stack.push(current);
      current = next;
    } else {
      current = stack.pop();
    }
  }
}

function getUnvisitedNeighbors(cell) {
  let dirs = [
    { x: 0, y: -1, dir: "top", opp: "bottom" },
    { x: 1, y: 0, dir: "right", opp: "left" },
    { x: 0, y: 1, dir: "bottom", opp: "top" },
    { x: -1, y: 0, dir: "left", opp: "right" },
  ];
  return dirs.map(d => {
    let nx = cell.x + d.x, ny = cell.y + d.y;
    if (nx >= 0 && ny >= 0 && nx < cols && ny < rows && !visited[ny][nx]) {
      return { x: nx, y: ny, dir: d.dir, opp: d.opp };
    }
  }).filter(Boolean);
}

function removeWalls(a, b) {
  maze[a.y][a.x][b.dir] = false;
  maze[b.y][b.x][b.opp] = false;
}

function drawMaze() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  for (let y = 0; y < rows; y++) {
    for (let x = 0; x < cols; x++) {
      let cell = maze[y][x];
      ctx.strokeStyle = "white";
      ctx.lineWidth = 2;
      if (cell.top) drawLine(x, y, x + 1, y);
      if (cell.right) drawLine(x + 1, y, x + 1, y + 1);
      if (cell.bottom) drawLine(x + 1, y + 1, x, y + 1);
      if (cell.left) drawLine(x, y + 1, x, y);
    }
  }

  ctx.fillStyle = "lime";
  ctx.fillRect(player.x * size + 4, player.y * size + 4, size - 8, size - 8);
  ctx.fillStyle = "red";
  ctx.fillRect(enemy.x * size + 10, enemy.y * size + 10, size - 20, size - 20);
  ctx.fillStyle = "gold";
  ctx.fillRect((cols - 1) * size + 20, (rows - 1) * size + 20, size - 40, size - 40);
}

function drawLine(x1, y1, x2, y2) {
  ctx.beginPath();
  ctx.moveTo(x1 * size, y1 * size);
  ctx.lineTo(x2 * size, y2 * size);
  ctx.stroke();
}

document.addEventListener("keydown", e => {
  if (gameOver) return;
  let move = { x: 0, y: 0 };
  if (e.key === "ArrowUp" && !maze[player.y][player.x].top) move.y = -1;
  if (e.key === "ArrowDown" && !maze[player.y][player.x].bottom) move.y = 1;
  if (e.key === "ArrowLeft" && !maze[player.y][player.x].left) move.x = -1;
  if (e.key === "ArrowRight" && !maze[player.y][player.x].right) move.x = 1;

  player.x += move.x;
  player.y += move.y;

  if (powerup === "teleport") {
    player.x = cols - 1;
    player.y = rows - 1;
  }

  checkWin();
});

function moveEnemy() {
  const queue = [[enemy]];
  const visited = new Set();
  visited.add(`${enemy.x},${enemy.y}`);

  while (queue.length > 0) {
    const path = queue.shift();
    const { x, y } = path[path.length - 1];
    if (x === player.x && y === player.y) {
      if (path.length > 1) {
        enemy = path[1];
      }
      break;
    }
    for (const [dx, dy, dir] of [[0,-1,'top'],[1,0,'right'],[0,1,'bottom'],[-1,0,'left']]) {
      let nx = x + dx, ny = y + dy;
      if (nx >= 0 && ny >= 0 && nx < cols && ny < rows && !maze[y][x][dir]) {
        const key = `${nx},${ny}`;
        if (!visited.has(key)) {
          visited.add(key);
          queue.push([...path, { x: nx, y: ny }]);
        }
      }
    }
  }
  if (enemy.x === player.x && enemy.y === player.y) gameOver = true;
}

function checkWin() {
  if (player.x === cols - 1 && player.y === rows - 1) {
    alert("🎉 You Escaped!");
    gameOver = true;
  }
}

function updateUI() {
  document.getElementById("timer").textContent = `Time: ${timer}s";
  document.getElementById("powerup").textContent = `Power-up: ${powerup || 'None'}`;
}

generateMaze();
setInterval(() => {
  if (!gameOver) {
    moveEnemy();
    drawMaze();
    updateUI();
    if (--timer <= 0) {
      alert("⏰ Time's up! You Lost!");
      gameOver = true;
    }
  }
}, 500);
